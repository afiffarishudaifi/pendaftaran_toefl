<footer class="site-footer">
  <div class="site-footer-legal">© 2022 <a href="http://themeforest.net/item/remark-responsive-bootstrap-admin-template/11989202">Pendaftaran Toefl Universitas PGRI Madiun</a></div>
  <div class="site-footer-right">
    Crafted with <i class="red-600 icon md-favorite"></i> by <a href="https://themeforest.net/user/creation-studio">Creation Studio</a>
  </div>
</footer>
